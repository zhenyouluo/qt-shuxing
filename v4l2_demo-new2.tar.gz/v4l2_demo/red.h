#ifndef RED_H
#define RED_H

void curr_data_set(void *data, int len);
void curr_data_get(void **data, int *len);
void red_detect_start();

#endif // RED_H
