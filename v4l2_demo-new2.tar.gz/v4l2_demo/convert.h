#ifndef __CONVERT_H
#define __CONVERT_H

int mjpeg2bgr(unsigned char *in, int len, unsigned char *out, int out_len);
int mjpeg2rgb(unsigned char *in, int len, unsigned char *out, int out_len);

int mjpeg_info(unsigned char *in, int len, int *width, int *height);

#endif