#include "widget.h"
#include "queue.h"
#include "convert.h"
#include "red.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


Widget::Widget()
{
    myThread = new Thread;
    QVBoxLayout *layout1 = new QVBoxLayout;
    QHBoxLayout *layout2 = new QHBoxLayout;

    QGraphicsScene *scene = new QGraphicsScene;
    scene->addItem(&item); //add image item

    QGraphicsView *view = new QGraphicsView(scene);
    layout1->addWidget(view);

    QPushButton *btn_cap = new QPushButton("cap");
    btn_cap->setFixedSize(40, 30);
    layout2->addWidget(btn_cap, 0, Qt::AlignLeft);

    statusLine = new QLineEdit();
    statusLine->setReadOnly(true);
    statusLine->setMaximumWidth(120);
    layout2->addWidget(statusLine, 1, Qt::AlignLeft);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addLayout(layout1);
    mainLayout->addLayout(layout2);
    setLayout(mainLayout);

    connect(myThread, SIGNAL(ImageSignal()), this, SLOT(ImageSlot()));
    connect(btn_cap, SIGNAL(clicked()), this, SLOT(ImageCap()));
    setWindowTitle("webcam Test");
    setFixedSize(640 + 25, 480 + 25 + 30 + 10);
    myThread->start();

    option = new QAction("Option", this);
    addAction(option);
    setContextMenuPolicy(Qt::ActionsContextMenu);
    connect(option, SIGNAL(triggered()), this, SLOT(OptionClicked()));
    bgr_data = (unsigned char *)malloc(1920*1080*3);
    red_detect_start();
}

Widget::~Widget() {
    free(bgr_data);
}


void Widget::RefreshImage(const void *buf, int len)
{
    if(buf == NULL || len <= 0) return;

    int width, height;
    if(mjpeg_info((unsigned char *)buf, len, &width, &height) < 0) { //jpg fomat error
        return;
    }
    if(width*height > 1920*1080) { //max 1080p
        return;
    }
    mjpeg2rgb((unsigned char *)buf, len, bgr_data, width*height*3);
    QImage img = QImage((unsigned char *)bgr_data, width, height, QImage::Format_RGB888);
    QPainter qPainter(&img);
    qPainter.setBrush(Qt::NoBrush);
    qPainter.setPen(Qt::red);
    qPainter.drawRect(10,10,200,200);
    qPainter.end();

    if(width != 640) {
        QPixmap pix = QPixmap::fromImage(img.scaledToWidth(640));
        item.setPixmap(pix);
    } else {
        QPixmap pix = QPixmap::fromImage(img);
        item.setPixmap(pix);
    }
}


void Widget::ImageSlot()
{
    void *data;
    int len;
    do {
        data = NULL;
        queue_pop(&data, &len);
        if(data == NULL) break;
        RefreshImage(data, len);
        curr_data_set(data, len);
        //queue_elem_free((void **)&data);
    } while(0);
}

void Widget::ImageCap() {
    void *data = NULL;
    int len;
    curr_data_get(&data, &len);
    if(data != NULL) {
        int fd = open("a.jpg", O_CREAT | O_WRONLY, 0644);
        if(fd >= 0) {
            write(fd, data, len);
            ::close(fd);
        }
        free(data);
    }
}

void Widget::OptionClicked() {
    printf("Option clicked\n");
}

void Widget::StopThread(void)
{
    myThread->SetStop();
    usleep(Thread_SLEEP_MS * 1000);
    myThread->terminate();
}
