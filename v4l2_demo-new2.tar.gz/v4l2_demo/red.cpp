#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include "convert.h"

void *curr_data = 0;
int curr_len = 0;
pthread_mutex_t  curr_lock = PTHREAD_MUTEX_INITIALIZER;
#define MAX_FACE_COUNT 10
//face count, score and position
int g_facecount = 0;
int g_facescores[MAX_FACE_COUNT];

void curr_data_set(void *data, int len)
{
    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        free(curr_data);
        curr_data = NULL;
    }
    curr_data = data;
    curr_len = len;
    pthread_mutex_unlock(&curr_lock);
}

void curr_data_get(void **data, int *len)
{

    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        *len = curr_len;
        *data = curr_data;
        curr_data = NULL;
        curr_len = 0;
    }
    pthread_mutex_unlock(&curr_lock);
}

static void do_detect(unsigned char *data, int len) {
    int width, height;
    if(mjpeg_info((unsigned char *)data, len, &width, &height) < 0) { //jpg fomat error
        return;
    }
    unsigned char *bgr_data = (unsigned char *)malloc(width*height*3);
    mjpeg2bgr((unsigned char *)data, len, bgr_data, width*height*3);
    free(bgr_data);
}

static void* detect_func(void *arg)
{
    int len;
    unsigned char *data;
    while(1) {
        curr_data_get((void **)&data, &len);
        if(data != NULL && len > 0) {
            do_detect(data, len);
            free(data);
            data = NULL;
            len = 0;
        } else {
            usleep(33000);
        }
    }
    return NULL;
}

void red_detect_start()
{
    pthread_t t1;
    pthread_create(&t1, NULL, detect_func, NULL);
    pthread_detach(t1);
}

