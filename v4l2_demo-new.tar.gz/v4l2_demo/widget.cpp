#include "widget.h"
#include "queue.h"
#include "convert.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void *curr_data = 0;
int curr_len = 0;
pthread_mutex_t  curr_lock = PTHREAD_MUTEX_INITIALIZER;

static void curr_data_set(void *data, int len) {
    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        free(curr_data);
        curr_data = NULL;
    }
    curr_data = data;
    curr_len = len;
    pthread_mutex_unlock(&curr_lock);
}

static void curr_data_get(void **data, int *len) {

    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        *len = curr_len;
        unsigned char *p = (unsigned char *)malloc(curr_len);
        memcpy(p, curr_data, curr_len);
        *data = p;
    }
    pthread_mutex_unlock(&curr_lock);
}

Widget::Widget()
{
    myThread = new Thread;
    QVBoxLayout *layout = new QVBoxLayout;

    QGraphicsScene *scene = new QGraphicsScene;
    scene->addItem(&item); //add image item

    QGraphicsView *view = new QGraphicsView(scene);
    layout->addWidget(view);

    QPushButton *btn_cap = new QPushButton("cap");
    btn_cap->setFixedSize(40, 30);
    layout->addWidget(btn_cap);

    setLayout(layout);

    connect(myThread, SIGNAL(ImageSignal()), this, SLOT(ImageSlot()));
    connect(btn_cap, SIGNAL(clicked()), this, SLOT(ImageCap()));
    setWindowTitle("webcam Test");
    setFixedSize(640 + 25, 480 + 25 + 30 + 10);
    myThread->start();

    option = new QAction("Option", this);
    addAction(option);
    setContextMenuPolicy(Qt::ActionsContextMenu);
    connect(option, SIGNAL(triggered()), this, SLOT(OptionClicked()));
    bgr_data = (unsigned char *)malloc(1920*1080*3);
}

Widget::~Widget() {
    free(bgr_data);
}


void Widget::RefreshImage(const void *buf, int len)
{
    if(buf == NULL || len <= 0) return;

    int width, height;
    if(mjpeg_info((unsigned char *)buf, len, &width, &height) < 0) { //jpg fomat error
        return;
    }
    if(width*height > 1920*1080) { //max 1080p
        return;
    }
    mjpeg2bgr((unsigned char *)buf, len, bgr_data, width*height*3);
    QPixmap pix = QPixmap::fromImage(QImage((unsigned char *)bgr_data, width, height, QImage::Format_RGB888));

    item.setPixmap(pix);
}


void Widget::ImageSlot()
{
    void *data;
    int len;
    while(1) {
        data = NULL;
        queue_pop(&data, &len);
        if(data == NULL) break;
        RefreshImage(data, len);
        curr_data_set(data, len);
        //queue_elem_free((void **)&data);
    }
}

void Widget::ImageCap() {
    void *data = NULL;
    int len;
    curr_data_get(&data, &len);
    if(data != NULL) {
        int fd = open("a.jpg", O_CREAT | O_WRONLY, 0644);
        if(fd >= 0) {
            write(fd, data, len);
            ::close(fd);
        }
        free(data);
    }
}

void Widget::OptionClicked() {
    printf("Option clicked\n");
}

void Widget::StopThread(void)
{
    myThread->SetStop();
    usleep(Thread_SLEEP_MS * 1000);
    myThread->terminate();
}
