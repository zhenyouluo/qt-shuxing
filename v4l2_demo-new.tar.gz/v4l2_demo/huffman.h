#ifndef HUFFMAN_H
#define HUFFMAN_H

#define HUFFMAN_DATA_LEN 420
int memcpy_picture(void *dst, void *src, int size);

#endif // HUFFMAN_H
