/********************************************************************
* author 周翔
* e-mail 604487178@qq.com
* blog http://blog.csdn.net/zhx6044
**********************************************************************/

#ifndef CHANNEL_H
#define CHANNEL_H

/**
 * @brief The Channel class
 * 支持分组频道
 *
 */

class Channel
{
public:
    Channel();
private:
    int Channel_id;

};

#endif // CHANNEL_H
