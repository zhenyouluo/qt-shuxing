#ifndef COMMANDTYPE_H
#define COMMANDTYPE_H

enum commandType{isCam = 0,isADMIN,isCMD};

#endif // COMMANDTYPE_H
