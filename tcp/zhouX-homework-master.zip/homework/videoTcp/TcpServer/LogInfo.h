#ifndef LOGINFO_H
#define LOGINFO_H

#include <QString>

struct LogMessage
{
    QString ip;
    QString startTime;
    QString dev_name;
    QString other;
};

#endif // LOGINFO_H
