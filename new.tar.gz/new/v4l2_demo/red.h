#ifndef RED_H
#define RED_H
#include "convert.h"
#include "TextureAS.h"
#include "widget.h"
void curr_data_set(void *data, int len);
void curr_data_get(void **data, int *len);
void red_detect_start();
extern int red_count;
extern TLiveness red_live[10];
extern struct timeval tv1, tv2,tv3;
extern QString time_rgb;
#endif // RED_H
