#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include<sys/time.h>
#include <stdio.h>
//#include "convert.h"
//#include "TextureAS.h"
#include"red.h"
#include<iostream>
#include "widget.h"
using namespace std;
void *curr_data = 0;
int curr_len = 0;
pthread_mutex_t  curr_lock = PTHREAD_MUTEX_INITIALIZER;
#define MAX_FACE_COUNT 10
//face count, score and position
int g_facecount = 0;
int g_facescores[MAX_FACE_COUNT];
struct timeval tv1, tv2,tv3;
TLiveness red_live[10];
int red_count;
HTAS htas1 = TAS_Create("TC1.dat","TT.bmd", "quality");
QString time_rgb;
void curr_data_set(void *data, int len)
{
    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        free(curr_data);
        curr_data = NULL;
    }
    curr_data = data;
    curr_len = len;
    pthread_mutex_unlock(&curr_lock);
}

void curr_data_get(void **data, int *len)
{

    pthread_mutex_lock(&curr_lock);
    if(curr_data != NULL) {
        *len = curr_len;
        *data = curr_data;
        curr_data = NULL;
        curr_len = 0;
    }
    pthread_mutex_unlock(&curr_lock);
}

static void do_detect(unsigned char *data, int len) {
    int width, height;
    if(mjpeg_info((unsigned char *)data, len, &width, &height) < 0) { //jpg fomat error
        return;
    }
    unsigned char *bgr_data = (unsigned char *)malloc(width*height*3);
     gettimeofday (&tv1, NULL);
    mjpeg2bgr((unsigned char *)data, len, bgr_data, width*height*3);
    /***************************/

    gettimeofday(&tv3, NULL);
    // time_a.sprintf("图片转换时间: %dms",(tv2.tv_sec - tv1.tv_sec)*1000 + (tv2.tv_usec - tv1.tv_usec)/1000);
    //live_time->setText(QString (time_a));
    time_rgb.sprintf("%dms",(tv3.tv_sec - tv1.tv_sec)*1000 + (tv3.tv_usec - tv1.tv_usec)/1000);

     gettimeofday (&tv1, NULL);
     red_count = TAS_Detect(htas1, (unsigned char*)bgr_data,  width, height,width*3, 10,red_live);

          //printf("====================TAS_Detect1 time: %ldms\n", (tv2.tv_sec - tv1.tv_sec)*1000 + (tv2.tv_usec - tv1.tv_usec)/1000);

        //  cout<<"asdasd"<<red_count<<endl;
          if(red_count!=0){
              gettimeofday(&tv2, NULL);
              //time_b.sprintf("活体识别时间: %dms 比分:%f",(tv2.tv_sec - tv1.tv_sec)*1000 + (tv2.tv_usec - tv1.tv_usec)/1000,red_live[0].score);
            // live_time2->setText(QString (time_b));
              cout << red_live[0].ptEyes[0].x << " " << red_live[0].ptEyes[0].y <<endl;
              cout<<red_live[0].rtFace.left<<" "<<red_live[0].rtFace.right<<" "<<red_live[0].rtFace.top<<" "<<red_live[0].rtFace.bottom<<endl;
              // drawRectangle(bgr_data, width, height, int(red_live[0].rtFace.left),int(red_live[0].rtFace.top+10) ,int(red_live[0].rtFace.right) ,int( red_live[0].rtFace.bottom));

    }

    //live_time2->setText(" ");
    /******************************/
    free(bgr_data);
}

static void* detect_func(void *arg)
{
    int len;
    unsigned char *data;
    while(1) {
        curr_data_get((void **)&data, &len);
        if(data != NULL && len > 0) {
            do_detect(data, len);
            free(data);
            data = NULL;
            len = 0;
        } else {
            usleep(33000);
        }
    }
    return NULL;
}

void red_detect_start()
{
    pthread_t t1;
    pthread_create(&t1, NULL, detect_func, NULL);
    pthread_detach(t1);
}

